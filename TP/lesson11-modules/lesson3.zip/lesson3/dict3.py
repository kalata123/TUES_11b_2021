dict = {'Student Name': 'Berry', 'Roll No.': 12, 'Subject': 'English'}
print("{Keys}:{Values}")
for key, value in dict.items():
 print({key},":",{value})