# Sorry for the shitty code :)
## Something came up and couldn't really finish all things, hope this is enough